<?php return array (
  'is_enabled' => 'true',
  'SalesOrderWS' => 
  array (
    'm' => 'SalesOrder',
    'download_pdf' => 'true',
    'list_fields' => 
    array (
      0 => 'salesorder_no',
      1 => 'contact_id',
      2 => 'duedate',
      3 => 'hdnGrandTotal',
      4 => 'account_id',
      5 => 'subject',
    ),
    'detail_fields' => 
    array (
      'BLOCK_1' => 
      array (
        0 => 'salesorder_no',
        1 => 'subject',
        2 => 'contact_id',
        3 => 'account_id',
        4 => 'duedate',
        5 => 'hdnGrandTotal',
      ),
    ),
  ),
) ;